﻿$stockList = $(Invoke-WebRequest -Uri "https://api.pse.tools/api/stocks").Content | ConvertFrom-Json |  Select -ExpandProperty Data | Select symbol
$db = @()

$stockList | % {
    $stock = $_.Symbol
    #$stock

    $stockData = $($(Invoke-WebRequest -Uri "https://ph24.colfinancial.com/ape/colcharts/HISTORICAL/$stock.asp").Content | ConvertFrom-Json) | Select Symbol, Date, Open, High, Low, Close, Volume | Sort-Object Date -Descending
    $stockData | % {
        $_.Symbol = $stock
    }
    Write-Host "$stock - $($stockData[0].Date)"
    $Old = Get-ChildItem -Path "$PSScriptRoot\PSE_DB\*_$stock.csv"
    Remove-Item -Path $old.FullName -Force
    $stockData | Export-Csv "$PSScriptRoot\PSE_DB\$($stockData[0].Date)_$($_.Symbol).csv"
}
