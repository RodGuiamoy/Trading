﻿cls
$VolumeBreakouts = @()
#$stockList = $(Invoke-WebRequest -Uri "https://api2.pse.tools/api/quotes").Content | ConvertFrom-Json | Select -ExpandProperty Data | gm | Select Name -Skip 4
$stockList = $(Invoke-WebRequest -Uri "https://api.pse.tools/api/stocks").Content | ConvertFrom-Json |  Select -ExpandProperty Data | Select symbol

$stockList | % {
    $stock = $_.Symbol
    $stock
    #$stockData = $($(Invoke-WebRequest -Uri "https://ph24.colfinancial.com/ape/colcharts/HISTORICAL/$stock.asp").Content | ConvertFrom-Json) | Select Date, Open, High, Low, Close | Sort-Object Date -Descending
    #$stockData[0].Date
    $stockData = Import-Csv -Path "$PSScriptRoot\PSE_DB\*_$stock.csv"
    
    <#$filterYear = $($([datetime]$stockData[0].Date).AddMonths(-7)).ToString('yyyy')
    $filterMonth = $($([datetime]$stockData[0].Date).AddMonths(-7)).ToString('MM')
    $filterDate = [datetime]"$filterMonth/01/$filterYear"#>
    #$filterDate
    
    $MonthlyVolumeData = @()
    for($i = 0; $i -le 5; $i++){
        $filterYear = $($([datetime]$stockData[0].Date).AddMonths(-$i)).ToString('yyyy')
        $filterMonth = $($([datetime]$stockData[0].Date).AddMonths(-$i)).ToString('MM')
        $filterDate = [datetime]"$filterMonth/01/$filterYear"
        #$filterDate

        $data = $stockData | Select Date, Volume | Where-Object {($([datetime]$_.Date) -ge $filterDate) -and ($([datetime]$_.Date) -lt $filterDate.AddMonths(1))}
        $MonthlyVolumeData += $($data | Measure-Object -Property Volume -Sum).Sum
    }
    #$MonthlyVolumeData
    If([double]$MonthlyVolumeData[0] -gt [double]$($MonthlyVolumeData[1..5] | Measure-Object -Maximum).Maximum){
        Write-Host "`tNew 6-month high volume!"
        $VolumeBreakouts += $stock
    }
    
    "`n"
}

#$VolumeBreakouts > "C:\Users\Rod Guiamoy\Desktop\Stock Screeners v2\VolumeBreakout\VolumeBreakout_$($([datetime]$stockData[0].Date).ToString('MMddyyyy')).txt"
$VolumeBreakouts > "$PSScriptRoot\VolumeBreakout\VolumeBreakout_$($([datetime]$stockData[0].Date).ToString('MMddyyyy')).txt"
#$Breakwatch | Export-Csv "$PSScriptRoot\BreakWatch\BreakWatch_$($([datetime]$stockData[0].Date).ToString('MMddyyyy')).csv"
Write-Host "END"